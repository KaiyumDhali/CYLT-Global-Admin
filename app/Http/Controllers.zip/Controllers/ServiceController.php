<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceModel;
use App\Models\Category;

class ServiceController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $services = ServiceModel::all();
        return view('service.add', compact('services','categories')); 
    }

    public function serviceList()
    {
        $services = ServiceModel::all();
        return view('service.serviceslist', compact('services'));
    }

    public function store(Request $request)
{
    $request->validate([
        'title.*'       => 'required|string|max:255',
        'description.*' => 'nullable|string|max:500',
        'othertext.*'   => 'nullable|string|max:500',
        'image.*'       => 'required|image|mimes:jpeg,png,jpg|max:2048',
        'category_id'   => 'nullable|exists:categories,id',
        'new_category'  => 'nullable|string|max:255',
    ]);

    // Handle new category
    if ($request->filled('new_category')) {
        $category = Category::create(['name' => $request->new_category]);
        $categoryId = $category->id;
    } else {
        $categoryId = $request->category_id;
    }

    // Store multiple services
    foreach ($request->file('image') as $index => $file) {
        $name = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
        $file->move(storage_path('app/public/images/services'), $name);

        ServiceModel::create([
            'category_id' => $categoryId,
            'image'       => 'images/services/' . $name,
            'title'       => $request->title[$index] ?? null,
            'description' => $request->description[$index] ?? null,
            'othertext'   => $request->othertext[$index] ?? null,
        ]);
    }

    return redirect()->route('services.list')->with('success', 'Service uploaded successfully!');
}


    public function edit($id)
    {
        $categories = Category::all(); // সব category পাঠানো হলো
        $service = ServiceModel::findOrFail($id);
        return view('service.servicesedit', compact('service','categories'));
    }
public function update(Request $request, $id)
{
    $request->validate([
        'image.*'       => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'title'         => 'nullable|string|max:255',
        'description'   => 'nullable|string|max:500',
        'othertext'     => 'nullable|string|max:500',
    ]);

    $service = ServiceModel::findOrFail($id);

    $data = [
        'title'       => $request->title,
        'description' => $request->description,
        'othertext'   => $request->othertext,
    ];

   if ($request->hasFile('image')) {
    // Delete old images if exist
    $oldImages = $service->image ? explode(',', $service->image) : [];
    if (is_array($oldImages)) {
        foreach ($oldImages as $img) {
            if (file_exists(public_path('storage/' . $img))) {
                unlink(public_path('storage/' . $img));
            }
        }
    }

    $newImages = [];
    foreach ($request->file('image') as $file) {
        $name = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
        $file->move(storage_path('app/public/images/services'), $name);
        $newImages[] = 'images/services/' . $name;
    }

    // Store as comma-separated string, same as store method
    $data['image'] = implode(',', $newImages);
}

    $service->update($data);

    return back()->with('success', 'Service updated successfully!');
}


    public function destroy($id)
    {
        $service = ServiceModel::findOrFail($id);

        // Delete the image file from storage
        if ($service->image && file_exists(public_path('storage/' . $service->image))) {
            unlink(public_path('storage/' . $service->image));
        }

        $service->delete();

        return back()->with('success', 'Service deleted successfully!');
    }
}
