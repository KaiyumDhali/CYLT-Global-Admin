<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\ProductFeature;
use App\Models\ProductCategory;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{

     //admin
         public function index(Request $request)
    {
        // Simple filter example (latest first)
        $products = ProductModel::with('category', 'features')
                        ->orderBy('created_at', 'desc')
                        ->paginate(12); // 12 per page

        return view('frontend.product.index', compact('products'));
    }

    public function list()
    {
        $products = ProductModel::with('category', 'features')->get();
        return view('product.productlist', compact('products'));
    }

    public function create()
    {
        $categories = ProductCategory::all();
        return view('product.add', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'description' => 'nullable|string',
            'status' => 'required|in:0,1',
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'feature' => 'nullable|array'
        ]);

         // Handle images
        $imagePaths = [];
        if($request->hasFile('images')) {
            foreach($request->file('images') as $file) {
                $name = time().'_'.uniqid().'.'.$file->getClientOriginalExtension();
                $file->move(storage_path('app/public/images/products'), $name);
                $imagePaths[] = 'images/products/'.$name;
            }
        }

        $product = ProductModel::create([
            'name' => $request->name,
            'category_id' => $request->category_id,
            'description' => $request->description,
            'status' => $request->status,
            'images' => implode(',', $imagePaths),
        ]);

         // Handle features
        if($request->features) {
            foreach($request->features as $feature) {
                if($feature) {
                    ProductFeature::create([
                        'product_id' => $product->id,
                        'feature' => $feature
                    ]);
                }
            }
        }

        return redirect()->route('products.list')->with('success', 'Product added successfully.');
    }

    public function edit($id)
    {
        $product = ProductModel::with('features')->findOrFail($id);
        $categories = ProductCategory::all();
        return view('product.productedit', compact('product', 'categories'));
    }

  public function update(Request $request, $id)
{
    $product = ProductModel::findOrFail($id);

    $request->validate([
        'name' => 'required|string|max:255',
        'category_id' => 'nullable|exists:product_categories,id',
        'description' => 'nullable|string',
        'status' => 'required|in:0,1',
        'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
        'features' => 'nullable|array'
    ]);

    // Delete old images from storage
    if($product->images){
        foreach(explode(',', $product->images) as $img){
            if(Storage::disk('public')->exists($img)){
                Storage::disk('public')->delete($img);
            }
        }
    }

    $imagePaths = [];
    // Store new images
    if($request->hasFile('images')) {
        foreach($request->file('images') as $file) {
            $name = time().'_'.uniqid().'.'.$file->getClientOriginalExtension();
            $file->move(storage_path('app/public/images/products'), $name);
            $imagePaths[] = 'images/products/'.$name;
        }
    }

    // Update product
    $product->update([
        'name' => $request->name,
        'category_id' => $request->category_id,
        'description' => $request->description,
        'status' => $request->status,
        'images' => $imagePaths ? implode(',', $imagePaths) : null,
    ]);

    // Update features (replace old with new)
    $product->features()->delete();
    if($request->features){
        foreach($request->features as $feature){
            if($feature){
                ProductFeature::create([
                    'product_id' => $product->id,
                    'feature' => $feature
                ]);
            }
        }
    }

    return redirect()->route('products.list')->with('success', 'Product updated successfully.');
}


    public function destroy($id)
    {
        $product = ProductModel::findOrFail($id);

        // Delete images from storage
        if($product->images){
            foreach(explode(',', $product->images) as $img){
                if(Storage::disk('public')->exists($img)){
                    Storage::disk('public')->delete($img);
                }
            }
        }

        $product->features()->delete();
        $product->delete();

        return redirect()->route('products.list')->with('success', 'Product deleted successfully.');
    }
}
