<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductModel extends Model
{
    use HasFactory;

    protected $table = 'products'; // মূল table products
    protected $fillable = ['name', 'description', 'category_id','images','status'];

    // একটি model এর অনেক feature থাকতে পারে
    public function features() {
        return $this->hasMany(ProductFeature::class, 'product_id');
    }

    // model এর category
    public function category() {
        return $this->belongsTo(ProductCategory::class, 'category_id');
    }
}
